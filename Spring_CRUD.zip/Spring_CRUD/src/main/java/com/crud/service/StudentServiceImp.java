package com.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.entity.Student;
import com.crud.repository.StudentRepository;

@Service
public class StudentServiceImp implements StudentService {

	@Autowired
	private StudentRepository stu_repo;
	
	 @Override
	 public void saveStudent(Student student) {
	      
		 stu_repo.save(student);
	 }
	 
	 @Override
	 public List<Student> getAllStudents() {
	     return stu_repo.findAll();
	 }
	 @Override
	 public void deleteStudentById(Long id) {
		 stu_repo.deleteById(id); 
	 }
	 @Override
	 public Student getStudentById(Long id) {
		 return stu_repo.findById(id).orElse(null);
	 }
	 @Override
	 public void updateStudent(Student student) {
	      
		 stu_repo.save(student);
	 }
}
