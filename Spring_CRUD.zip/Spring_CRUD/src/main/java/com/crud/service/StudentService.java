package com.crud.service;

import java.util.List;

import com.crud.entity.Student;

public interface StudentService {
	
	void saveStudent(Student student);
	List<Student> getAllStudents();
	void deleteStudentById(Long id);
	Student getStudentById(Long id);
	void updateStudent(Student student);
}
