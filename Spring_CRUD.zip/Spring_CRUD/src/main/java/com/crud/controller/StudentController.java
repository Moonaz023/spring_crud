package com.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.crud.entity.Student;
import com.crud.service.StudentService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class StudentController {

    /*@Autowired
    private StudentRepository stu_Repo;*/
    
    @Autowired
    private StudentService stu_serv;

    @GetMapping("/")
    public String showInsertStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "insertStudent";
    }


   /* @PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute Student stu )
	{
		System.out.println(stu);
		 stu_Repo.save(stu);
		return "redirect:/";
	}*/

	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute Student stu )
	{
		System.out.println(stu);
		stu_serv.saveStudent(stu);
		return "redirect:/";
	}
	
	 @GetMapping("student_list")
     public String showStudentList(Model model) {
		List<Student> studentList = stu_serv.getAllStudents();
	    model.addAttribute("students", studentList);
        return "studentList";
     }
	 
	 @GetMapping("/deleteStudent/{id}")
	 public String deleteStudent(@PathVariable Long id) 
	 {
	     stu_serv.deleteStudentById(id);
	     return "redirect:/student_list";
	  }
	 
	 @GetMapping("/editStudent/{id}")
     public String showEditStudentForm(@PathVariable Long id, Model model) 
	 {
        Student student = stu_serv.getStudentById(id);
        model.addAttribute("student", student);
        return "editStudent";
	 }
	 @PostMapping("/updateStudent")
	public String updateStudent(@ModelAttribute Student stu )
	{
		System.out.println(stu);
		stu_serv.updateStudent(stu);
		return "redirect:student_list";
	}

}
